﻿namespace Estates.Interfaces
{
    public interface IApartment : IBuildingEstate
    {
    }
}