﻿namespace MusicShop.Interfaces
{
    public interface IBassGuitar : IGuitar
    {
    }
}