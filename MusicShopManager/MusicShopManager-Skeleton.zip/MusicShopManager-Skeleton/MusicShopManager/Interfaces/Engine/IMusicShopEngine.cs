﻿namespace MusicShop.Interfaces.Engine
{
    public interface IMusicShopEngine
    {
        void Start();
    }
}
