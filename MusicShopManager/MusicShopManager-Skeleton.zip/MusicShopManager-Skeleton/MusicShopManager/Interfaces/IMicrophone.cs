﻿namespace MusicShop.Interfaces
{
    public interface IMicrophone : IArticle
    {
        bool HasCable { get; }
    }
}
