﻿namespace MusicShop.Models
{
    public enum StringMaterial
    {
        Steel,
        Brass,
        Bronze,
        Nylon
    }
}
