﻿namespace NightlifeEntertainment.Models.Performances
{
    public enum PerformanceType
    {
        Movie,
        Opera,
        Theatre,
        Sport,
        Concert
    }
}
