﻿namespace NightlifeEntertainment.Models.Tickets
{
    public enum TicketType
    {
        Regular,
        Student,
        VIP
    }
}
