﻿using Blobs.Core;

namespace Blobs
{
    public class Program
    {
        public static void Main()
        {
            Engine.Instance.Start();
        }
    }
}
