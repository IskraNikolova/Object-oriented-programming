﻿namespace Blobs.Models.InflantedBlobs
{
    public class PutridFartInflatedBlob : InflatedBlob
    {
        public PutridFartInflatedBlob(string name, int health, int damage) 
            : base(name, health, damage)
        {
        }
    }
}
