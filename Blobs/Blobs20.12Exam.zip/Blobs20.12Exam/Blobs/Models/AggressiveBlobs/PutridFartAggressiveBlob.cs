﻿namespace Blobs.Models.AggressiveBlobs
{
    public class PutridFartAggressiveBlob : AggressiveBlob
    {
        public PutridFartAggressiveBlob(string name, int health, int damage)
            : base(name, health, damage)
        {
        }
    }
}
