﻿namespace Blobs.Interfaces
{
    public interface IAggressiveBlob
    {
         
    }
}