﻿namespace Blobs.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}