﻿namespace Blobs.Interfaces
{
    public interface IInflantedBlob
    {
         
    }
}