﻿namespace Blobs.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string data);
    }
}