﻿namespace FurnitureManufacturer.Models.Furnitures
{
    public enum StateOfConvertableChair
    {
        Normal,
        Converted
    }
}