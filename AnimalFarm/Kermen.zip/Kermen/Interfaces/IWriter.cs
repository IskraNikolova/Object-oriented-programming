﻿namespace Kermen.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string input);
    }
}