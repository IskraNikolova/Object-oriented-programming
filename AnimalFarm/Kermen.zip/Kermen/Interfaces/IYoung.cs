﻿namespace Kermen.Interfaces
{
    public interface IYoung
    {
        decimal LaptopCoast { get; } 
    }
}