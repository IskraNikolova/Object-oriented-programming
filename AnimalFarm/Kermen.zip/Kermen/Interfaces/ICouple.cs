﻿namespace Kermen.Interfaces
{
    public interface ICouple 
    {
        decimal TVCoast { get; }
        
        decimal FridgeCoast { get; } 
    }
}