﻿namespace Kermen.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}