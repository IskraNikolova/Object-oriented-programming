﻿namespace FootballTeamGenerator.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string msg);
    }
}