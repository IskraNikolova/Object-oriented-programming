﻿namespace LambdaCore_Skeleton.Models.Cores
{
    using Enums;

    public class ParaBaseCore : BaseCore
    {
        private const int DividerOfDurability = 3;
        
        public ParaBaseCore(char name, int startDurability) 
            : base(name, CoreType.Para, startDurability)
        {
        }

        public override int StartDurability
        {
            get
            {
                return base.StartDurability;
            }

            set
            {
                base.StartDurability = value/DividerOfDurability;
            }
        }
    }
}