﻿namespace LambdaCore_Skeleton.Interfaces
{
    using System.Collections.Generic;
    using Core;

    public interface IPowerPlant
    {
        IWritter Writer { get; }

        IReader Reader { get; }

        ICollection<ICore> Cores { get; }

        Factory Factory { get; }

        void Run();
    }
}