﻿namespace LambdaCore_Skeleton.Interfaces
{
    public interface IWritter
    {
        void WriteLine(string message);

        void Write(string message);
    }
}