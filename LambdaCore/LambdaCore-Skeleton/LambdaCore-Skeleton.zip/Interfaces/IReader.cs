﻿namespace LambdaCore_Skeleton.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}