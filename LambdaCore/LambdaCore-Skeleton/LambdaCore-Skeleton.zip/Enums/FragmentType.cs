﻿namespace LambdaCore_Skeleton.Enums
{
    public enum FragmentType
    {
        Nuclear,
        Cooling
    }
}