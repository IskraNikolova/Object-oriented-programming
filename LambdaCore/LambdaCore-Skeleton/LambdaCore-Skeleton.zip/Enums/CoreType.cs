﻿namespace LambdaCore_Skeleton.Enums
{
    public enum CoreType
    {
        System,
        Para
    }
}