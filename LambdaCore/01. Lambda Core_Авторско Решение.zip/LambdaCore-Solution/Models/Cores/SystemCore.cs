﻿namespace LambdaCore_Solution.Models.Cores
{
    public class SystemCore : BaseCore
    {
        public SystemCore(string name, int durability)
            : base(name, durability)
        {
        }
    }
}
