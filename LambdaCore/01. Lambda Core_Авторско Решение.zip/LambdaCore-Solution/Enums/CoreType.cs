﻿namespace LambdaCore_Solution.Enums
{
    public enum CoreType
    {
        System,
        Para
    }
}
