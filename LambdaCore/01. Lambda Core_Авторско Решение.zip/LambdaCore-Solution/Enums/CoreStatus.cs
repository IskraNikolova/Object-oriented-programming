﻿namespace LambdaCore_Solution.Enums
{
    public enum CoreStatus
    {
        NORMAL,
        CRITICAL
    }
}
