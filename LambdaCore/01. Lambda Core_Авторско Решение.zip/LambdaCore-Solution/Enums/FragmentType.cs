﻿namespace LambdaCore_Solution.Enums
{
    public enum FragmentType
    {
        Nuclear,
        Cooling
    }
}
