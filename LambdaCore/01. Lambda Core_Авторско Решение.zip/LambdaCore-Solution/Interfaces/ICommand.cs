﻿namespace LambdaCore_Solution.Interfaces
{
    public interface ICommand
    {
        string Execute();
    }
}
