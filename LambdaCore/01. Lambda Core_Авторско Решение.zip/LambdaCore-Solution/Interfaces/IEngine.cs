﻿namespace LambdaCore_Solution.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
