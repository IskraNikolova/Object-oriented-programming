﻿namespace LambdaCore_Solution.Interfaces
{
    public interface IInputReader
    {
        string ReadLine();
    }
}
