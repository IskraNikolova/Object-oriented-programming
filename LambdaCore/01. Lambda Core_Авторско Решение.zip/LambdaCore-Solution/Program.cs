﻿namespace LambdaCore_Solution
{
    using LambdaCore_Solution.Core;

    public class Program
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
