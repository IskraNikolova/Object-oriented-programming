﻿namespace LambdaCore_Skeleton.Models.Cores
{
    class SystemCore
    {
        public SystemCore(string name, int durability)
        {

        }
    }
}
