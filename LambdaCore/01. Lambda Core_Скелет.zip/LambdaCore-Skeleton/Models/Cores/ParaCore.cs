﻿namespace LambdaCore_Skeleton.Models.Cores
{
    using System;

    class ParaCore
    {
        public ParaCore(string name, int durability)
        {
        }
    }
}
