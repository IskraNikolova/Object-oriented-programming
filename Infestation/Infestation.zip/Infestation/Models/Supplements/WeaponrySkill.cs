﻿namespace Infestation.Models.Supplements
{
    public class WeaponrySkill : SupplementBase
    {
    }
}
