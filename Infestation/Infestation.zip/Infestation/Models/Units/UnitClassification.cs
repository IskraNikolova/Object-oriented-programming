﻿namespace Infestation.Models.Units
{
    public enum UnitClassification
    {
        Biological,
        Mechanical,
        Psionic,
        Unknown
    }
}
