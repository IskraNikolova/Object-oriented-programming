﻿namespace Infestation
{
    public enum InteractionType
    {
        Attack,
        Infest,
    }
}
