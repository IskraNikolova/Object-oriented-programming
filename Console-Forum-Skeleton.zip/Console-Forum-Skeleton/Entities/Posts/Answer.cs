﻿using ConsoleForum.Contracts;

namespace ConsoleForum.Entities.Posts
{
    class Answer : Post, IAnswer
    {
        public Answer(int id, string body, IUser author) 
            : base(id, body, author)
        {
        }
    }
}
